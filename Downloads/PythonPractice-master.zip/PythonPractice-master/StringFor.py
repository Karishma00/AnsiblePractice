str="Pyhton"

for i in str:
    print(i)


#Tuples
t=[(1,2,3),(4,5,6),(7,8,9)]
for (a,b,c) in t:
    print(a ,' : ',b ,' : ',c )

#Dictionary
d={'k1':1,'k2':2,'k3':3}
for i in d.items():
    print(i)