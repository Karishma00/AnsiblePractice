list=[1,'Pyhton','2.67','Singing']
list1=[67,98,42,34,53]
print(list)

#Indexing
print(list[2])

#Slicing
print(list[1:])

#pop
print(list.pop(2))

#sort
print(list1.sort())
print(list1)

#append
print(list.append(87.56))
print(list)


