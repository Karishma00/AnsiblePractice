sum=0
l=[1,6,7,3,5,10]

for i in l:
    sum=sum+i;
    print(f'The sum is : {sum}')
