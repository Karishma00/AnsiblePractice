x=0

while x<5:
    print(f'X is {x}')
    x=x+1
else:
    print('Wrong ..')



