str="Company"
s="K"
print(str)
print(str[2])

#indexing
print(str[-1])

#Slicing
print(str[1:6:2])
print(str[:2])
print(str[:2:-1])

#str[0]='K'
#print(str)

print(s+str)
print(str*2)

#method of strings
k='Ka ris hma Sala liya'
print(k.upper())

print(k.lower())

print(k.split())
print(k.split('a'))
print('Chips')

#String formatting



