str="Money"

if str=='Abc':
    print("Abc....")
elif str=='Money':
    print("Money....")
else:
    print("Wrong str...")


if True:
    print("True ...")
else:
    print('False..')
