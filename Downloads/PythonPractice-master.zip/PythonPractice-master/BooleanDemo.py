print(True)
print(False)

a=True
print(type(a))

print(10>30)

b=None
print(type(b))


