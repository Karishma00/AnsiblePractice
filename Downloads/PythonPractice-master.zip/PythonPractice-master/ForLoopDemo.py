#For loop demo

a=[1,2,3,4,5]
b=['a','b','c','d','e']

for n in a:
    print(n)

for n in b:
    print(n)

print("Even of Odd !!")
t=(1,2,3,4,5,6,7,8,9,10)

for i in t:
    if i%2==0:
        print(i," is even no ")
    else:
        print(i ," is odd no ")
