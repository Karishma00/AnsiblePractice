print(2==1)
print(4>=2)
print(4<=3)
print(1!=0)
print(10<8)
print(3>1)

print('hello'=='bye')

print(2.0==2)
print('Bye'=='bye')

#Chaining comparision op with logical op
print(1<2<3)
print(1<2>3)

#By using and both true then true
print(1<2 and 1>3)

#by using or One true then true both false then false
print(1<2 or 2>3)
print(1>3 or 3>5)

#by not
print(1!=4)