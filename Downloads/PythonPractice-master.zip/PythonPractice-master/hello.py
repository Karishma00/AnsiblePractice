print('hello')

str="my name is karishma"
print(len(str))
print(str[::-1])
print(str[11:])

a=5+5.78+4
print(a,type(a))

print(3**2)
print(9/3)
