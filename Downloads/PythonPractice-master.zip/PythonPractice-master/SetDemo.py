#set is unordered and Unique collection of items

set1={2,5,7,8,2}
print(set1)

#type
print(type(set1))

#adding the elements
set1.add(10)
print(set1)

set1.pop()
print(set1)

set2=set1.copy()
print(set2)

set1.clear();
print(set1)
print(set2)

print(set([1,1,2,3]))
print(set("Misssipppie"))
